# Video Akad + Undangan (Remotion)

Video origami: frame Ka'bah (detik 19) ditahan 5 detik, frame kartu undangan (detik 39) ditahan 7 detik.
Tulisan diketik satu-satu, hilang, lalu diganti tulisan berikutnya. Total durasi 62 detik, 1080x1920, 30 FPS.

## Cara render di GitHub (dari HP)
1. Buat repository baru di GitHub (boleh private).
2. Upload SEMUA isi folder ini (termasuk folder `.github`, `public`, `src`) ke repository.
   Tips HP: ekstrak ZIP dulu, atau pakai GitHub Desktop / Termux `git push`.
3. Buka tab **Actions** -> **Render Video** -> **Run workflow**.
4. Tunggu hijau (± 5-10 menit), buka run-nya, unduh **undangan-akad** di bagian *Artifacts*.

## Mau ganti tulisan / posisi / waktu?
Semuanya ada di `src/teks.ts`: isi tulisan, detik tahan, dan posisi tulisan (angka `top` / `kiri`).
