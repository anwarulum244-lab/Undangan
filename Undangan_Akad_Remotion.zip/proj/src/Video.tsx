import React from 'react';
import {AbsoluteFill, Freeze, OffthreadVideo, Sequence, staticFile} from 'remotion';
import {KetikHalaman} from './components/Ketik';
import {
  Halaman,
  POSISI_KABAH,
  POSISI_KARTU,
  TEKS_KABAH,
  TEKS_UNDANGAN,
  WAKTU,
} from './teks';

export const FPS = 30;
const f = (detik: number) => Math.round(detik * FPS);

// Total: video asli 50 dtk + 5 dtk tahan + 7 dtk tahan = 62 dtk
export const TOTAL_FRAME =
  f(WAKTU.durasiVideoAsli) + f(WAKTU.tahanKabah) + f(WAKTU.tahanUndangan);

const Klip: React.FC<{dari: number; durasi: number; beku?: boolean}> = ({
  dari,
  durasi,
  beku,
}) => {
  const video = (
    <OffthreadVideo
      src={staticFile('sumber.mp4')}
      startFrom={f(dari)}
      muted={beku}
      style={{width: '100%', height: '100%', objectFit: 'cover'}}
    />
  );
  return (
    <Sequence from={0} durationInFrames={durasi}>
      <AbsoluteFill>{beku ? <Freeze frame={0}>{video}</Freeze> : video}</AbsoluteFill>
    </Sequence>
  );
};

// Membagi durasi tahan ke tiap halaman sesuai panjang tulisannya
const bagiDurasi = (halaman: Halaman[], total: number): number[] => {
  const bobot = halaman.map(
    (h) => h.baris.reduce((a, b) => a + b.teks.length, 0) + 12,
  );
  const jumlah = bobot.reduce((a, b) => a + b, 0);
  const hasil = bobot.map((w) => Math.floor((total * w) / jumlah));
  hasil[hasil.length - 1] += total - hasil.reduce((a, b) => a + b, 0);
  return hasil;
};

const TulisanBeku: React.FC<{
  halaman: Halaman[];
  total: number;
  pos: {top: number; tinggi: number; kiri: number; lebar: number};
}> = ({halaman, total, pos}) => {
  const durasi = bagiDurasi(halaman, total);
  let mulai = 0;
  return (
    <>
      {halaman.map((h, i) => {
        const dari = mulai;
        mulai += durasi[i];
        return (
          <Sequence key={i} from={dari} durationInFrames={durasi[i]}>
            <div
              style={{
                position: 'absolute',
                top: pos.top,
                left: pos.kiri,
                width: pos.lebar,
                height: pos.tinggi,
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
              }}
            >
              <KetikHalaman halaman={h} durasi={durasi[i]} />
            </div>
          </Sequence>
        );
      })}
    </>
  );
};

export const Video: React.FC = () => {
  const a = f(WAKTU.detikKabah); // 19 dtk
  const tk = f(WAKTU.tahanKabah); // 5 dtk
  const b = f(WAKTU.detikUndangan); // 39 dtk
  const tu = f(WAKTU.tahanUndangan); // 7 dtk
  const akhir = f(WAKTU.durasiVideoAsli);

  const mulaiB = a + tk; // video lanjut dari detik 19
  const mulaiBeku2 = mulaiB + (b - a);
  const mulaiC = mulaiBeku2 + tu;

  return (
    <AbsoluteFill style={{backgroundColor: '#000'}}>
      {/* 1. Video jalan 0 -> 19 dtk */}
      <Sequence from={0} durationInFrames={a}>
        <Klip dari={0} durasi={a} />
      </Sequence>

      {/* 2. Tahan frame Ka'bah + tulisan diketik */}
      <Sequence from={a} durationInFrames={tk}>
        <Klip dari={WAKTU.detikKabah} durasi={tk} beku />
        <TulisanBeku halaman={TEKS_KABAH} total={tk} pos={POSISI_KABAH} />
      </Sequence>

      {/* 3. Video lanjut 19 -> 39 dtk */}
      <Sequence from={mulaiB} durationInFrames={b - a}>
        <Klip dari={WAKTU.detikKabah} durasi={b - a} />
      </Sequence>

      {/* 4. Tahan frame kartu undangan + tulisan diketik */}
      <Sequence from={mulaiBeku2} durationInFrames={tu}>
        <Klip dari={WAKTU.detikUndangan} durasi={tu} beku />
        <TulisanBeku halaman={TEKS_UNDANGAN} total={tu} pos={POSISI_KARTU} />
      </Sequence>

      {/* 5. Video lanjut 39 -> akhir */}
      <Sequence from={mulaiC} durationInFrames={akhir - b}>
        <Klip dari={WAKTU.detikUndangan} durasi={akhir - b} />
      </Sequence>
    </AbsoluteFill>
  );
};
