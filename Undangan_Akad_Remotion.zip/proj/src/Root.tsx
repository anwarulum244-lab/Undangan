import React from 'react';
import {Composition} from 'remotion';
import {FPS, TOTAL_FRAME, Video} from './Video';

export const RemotionRoot: React.FC = () => (
  <Composition
    id="UndanganAkad"
    component={Video}
    durationInFrames={TOTAL_FRAME}
    fps={FPS}
    width={1080}
    height={1920}
  />
);
