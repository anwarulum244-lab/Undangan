import React from 'react';
import {interpolate, useCurrentFrame} from 'remotion';
import {loadFont as loadSkrip} from '@remotion/google-fonts/GreatVibes';
import {loadFont as loadSerif} from '@remotion/google-fonts/CormorantGaramond';
import {loadFont as loadSerifMiring} from '@remotion/google-fonts/CormorantGaramond';
import {Baris, Gaya, Halaman, WARNA} from '../teks';
import {Hati} from './Hati';

const skrip = loadSkrip();
const serif = loadSerif('normal', {weights: ['600', '700'], subsets: ['latin']});
const serifMiring = loadSerifMiring('italic', {
  weights: ['600'],
  subsets: ['latin'],
});

const GAYA: Record<Gaya, React.CSSProperties> = {
  skrip: {fontFamily: skrip.fontFamily, fontSize: 140, lineHeight: 1.05},
  miring: {
    fontFamily: serifMiring.fontFamily,
    fontStyle: 'italic',
    fontWeight: 600,
    fontSize: 66,
    lineHeight: 1.15,
  },
  tegas: {
    fontFamily: serif.fontFamily,
    fontWeight: 700,
    fontSize: 62,
    lineHeight: 1.15,
    letterSpacing: 2,
  },
  kecil: {
    fontFamily: serif.fontFamily,
    fontWeight: 700,
    fontSize: 38,
    letterSpacing: 8,
    textTransform: 'uppercase',
  },
};

// Ukuran lebih kecil untuk halaman yang barisnya banyak (agar muat di kartu)
const SKALA_BANYAK_BARIS = 0.78;

const Kursor: React.FC<{frame: number; tinggi: number}> = ({frame, tinggi}) => {
  const nyala = Math.floor(frame / 8) % 2 === 0;
  return (
    <span style={{display: 'inline-block', width: 0, position: 'relative'}}>
      <span
        style={{
          position: 'absolute',
          left: 3,
          top: -tinggi * 0.85,
          width: 4,
          height: tinggi * 0.85,
          background: WARNA.tinta,
          opacity: nyala ? 0.8 : 0,
        }}
      />
    </span>
  );
};

// Satu halaman: semua barisnya diketik berurutan, ditahan, lalu memudar.
export const KetikHalaman: React.FC<{
  halaman: Halaman;
  durasi: number; // frame
}> = ({halaman, durasi}) => {
  const frame = useCurrentFrame();
  const banyak = halaman.baris.length > 2;
  const skala = banyak ? SKALA_BANYAK_BARIS : 1;

  const totalHuruf = halaman.baris.reduce((a, b) => a + b.teks.length, 0);
  const jatahKetik = durasi * 0.55; // 55% waktu halaman dipakai mengetik
  const framePerHuruf = Math.min(3, Math.max(1, jatahKetik / totalHuruf));

  const fadeKeluar = 9;
  const opacity = interpolate(
    frame,
    [durasi - fadeKeluar, durasi - 1],
    [1, 0],
    {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'},
  );
  const naik = interpolate(frame, [durasi - fadeKeluar, durasi - 1], [0, -14], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
  });

  let sisa = frame / framePerHuruf; // huruf yang sudah boleh tampil
  const tampil: {b: Baris; n: number; selesaiFrame: number; aktif: boolean}[] = [];
  let frameMulaiBaris = 0;
  halaman.baris.forEach((b) => {
    const n = Math.max(0, Math.min(b.teks.length, Math.floor(sisa)));
    const selesaiFrame = frameMulaiBaris + b.teks.length * framePerHuruf;
    tampil.push({
      b,
      n,
      selesaiFrame,
      aktif: sisa > 0 && sisa < b.teks.length + 6, // kursor tetap berkedip sebentar
    });
    sisa -= b.teks.length;
    frameMulaiBaris = selesaiFrame;
  });
  const barisAktif = tampil.findIndex((t) => t.n < t.b.teks.length);
  const idxKursor = barisAktif === -1 ? tampil.length - 1 : barisAktif;

  return (
    <div style={{opacity, transform: `translateY(${naik}px)`, textAlign: 'center'}}>
      {tampil.map((t, i) => {
        const g = {...GAYA[t.b.gaya]};
        g.fontSize = (g.fontSize as number) * skala;
        const hurufTampil = t.b.teks.slice(0, t.n);
        const hurufSisa = t.b.teks.slice(t.n);
        return (
          <div
            key={i}
            style={{
              ...g,
              color: WARNA.tinta,
              textShadow: `0 0 14px ${WARNA.cahaya}, 0 0 4px ${WARNA.cahaya}`,
              whiteSpace: 'nowrap',
              marginTop: i === 0 ? 0 : 6,
            }}
          >
            <span>{hurufTampil}</span>
            {i === idxKursor && frame < durasi - fadeKeluar ? (
              <Kursor frame={frame} tinggi={g.fontSize as number} />
            ) : null}
            <span style={{opacity: 0}}>{hurufSisa}</span>
            {t.b.hati && t.n >= t.b.teks.length ? (
              <Hati
                mulai={Math.ceil(t.selesaiFrame)}
                ukuran={(g.fontSize as number) * 0.7}
                warna={WARNA.hati}
              />
            ) : null}
          </div>
        );
      })}
    </div>
  );
};
