import React from 'react';
import {spring, useCurrentFrame, useVideoConfig} from 'remotion';

// Hati kecil yang muncul "pop" lalu berdetak pelan.
export const Hati: React.FC<{mulai: number; ukuran: number; warna: string}> = ({
  mulai,
  ukuran,
  warna,
}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const pop = spring({
    frame: frame - mulai,
    fps,
    config: {damping: 9, stiffness: 160},
  });
  const detak = 1 + 0.07 * Math.sin(Math.max(0, frame - mulai) / 5);
  return (
    <svg
      width={ukuran}
      height={ukuran}
      viewBox="0 0 24 24"
      style={{
        marginLeft: ukuran * 0.35,
        transform: `scale(${pop * detak})`,
        verticalAlign: 'middle',
        opacity: frame < mulai ? 0 : 1,
      }}
    >
      <path
        d="M12 21 C12 21 3 15.5 3 9.2 C3 6.4 5.1 4.5 7.6 4.5 C9.5 4.5 11.1 5.6 12 7.3 C12.9 5.6 14.5 4.5 16.4 4.5 C18.9 4.5 21 6.4 21 9.2 C21 15.5 12 21 12 21 Z"
        fill={warna}
      />
    </svg>
  );
};
