// =====================================================
//  SEMUA TULISAN & WAKTU ADA DI FILE INI.
//  Mau ganti tulisan? Cukup ubah teks di dalam tanda kutip.
// =====================================================

export type Gaya = 'skrip' | 'miring' | 'tegas' | 'kecil';

export type Baris = {
  teks: string;
  gaya: Gaya;
  hati?: boolean; // true = ada hati kecil yang "pop" setelah baris selesai diketik
};

// Satu "halaman" = satu tulisan yang diketik, lalu hilang, lalu diganti halaman berikutnya.
export type Halaman = {baris: Baris[]};

// ---------- Waktu (dalam detik, dari video asli) ----------
export const WAKTU = {
  detikKabah: 19, // video berhenti di detik ke-19
  tahanKabah: 5, // ditahan 5 detik
  detikUndangan: 39, // video berhenti di detik ke-39
  tahanUndangan: 7, // ditahan 7 detik
  durasiVideoAsli: 50, // video asli (dipakai sampai detik 50)
};

// ---------- Tulisan di Ka'bah (diketik satu-satu) ----------
export const TEKS_KABAH: Halaman[] = [
  {baris: [{teks: 'Alhamdulillah', gaya: 'skrip'}]},
  {baris: [{teks: 'akad sudah terlaksana', gaya: 'miring', hati: true}]},
  {baris: [{teks: '03 Juli 2026', gaya: 'tegas'}]},
  {baris: [{teks: 'di Masjidil Haram', gaya: 'miring'}]},
];

// ---------- Tulisan di kartu undangan (diketik satu-satu) ----------
export const TEKS_UNDANGAN: Halaman[] = [
  {
    baris: [
      {teks: "Walimatul 'Ursy", gaya: 'kecil'},
      {teks: 'Awang & Rahma', gaya: 'skrip'},
    ],
  },
  {baris: [{teks: 'Ahad, 22 November 2026', gaya: 'tegas'}]},
  {
    baris: [
      {teks: 'di kediaman mempelai wanita', gaya: 'miring'},
      {teks: 'Kampung Baru RT 2 RW 8', gaya: 'tegas'},
      {teks: 'Desa Cisarua, Kec. Nanggung', gaya: 'tegas'},
      {teks: 'Kab. Bogor, Jawa Barat', gaya: 'tegas'},
    ],
  },
  {baris: [{teks: 'Datang ya, bawa doa terbaik', gaya: 'miring', hati: true}]},
];

// ---------- Posisi tulisan (piksel, kanvas 1080 x 1920) ----------
// Ka'bah: tulisan di bawah pasangan kecil, di atas area tombol aplikasi.
export const POSISI_KABAH = {top: 1400, tinggi: 230, kiri: 60, lebar: 960};
// Kartu undangan: di tengah-atas kartu (menghindari rumah kecil di kanan-bawah kartu).
export const POSISI_KARTU = {top: 770, tinggi: 330, kiri: 190, lebar: 700};

export const WARNA = {
  tinta: '#5a3e1b', // cokelat emas tua
  cahaya: 'rgba(250,243,228,0.95)', // cahaya krem di belakang huruf
  hati: '#d9798f', // pink lembut
};
